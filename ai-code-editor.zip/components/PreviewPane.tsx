
import React, { useEffect, useState, useMemo } from 'react';
import { DynamicReactComponent } from '../types';

interface PreviewPaneProps {
  generatedCode: string;
  onCompileError: (error: string) => void;
  onRuntimeError: (error: string) => void;
}

// Minimal styling for error boundaries within the preview
const errorBoundaryStyle: React.CSSProperties = {
  padding: '16px',
  margin: '16px',
  backgroundColor: '#fee2e2',
  color: '#dc2626',
  border: '1px solid #ef4444',
  borderRadius: '8px',
  fontFamily: 'monospace',
  whiteSpace: 'pre-wrap',
  overflowX: 'auto',
};

// Error Boundary Component
interface ErrorBoundaryProps {
  children: React.ReactNode;
  onError: (error: Error, errorInfo: React.ErrorInfo) => void;
  fallback: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo): void {
    this.props.onError(error, errorInfo);
  }

  render(): React.ReactNode {
    if (this.state.hasError) {
      return this.props.fallback;
    }
    return this.props.children;
  }
}


const PreviewPane: React.FC<PreviewPaneProps> = ({ generatedCode, onCompileError, onRuntimeError }) => {
  const [ComponentToRender, setComponentToRender] = useState<DynamicReactComponent>(null);
  const [compileError, setCompileError] = useState<string | null>(null);

  useEffect(() => {
    setCompileError(null); // Clear previous compile errors
    if (!generatedCode.trim()) {
      setComponentToRender(null);
      return;
    }

    try {
      // WARNING: Using 'eval' is a security risk if the code source is untrusted.
      // For a code editor/playground scenario where the user generates code for themselves,
      // it's a common pattern, but it should be used with extreme caution in production.
      // In a real application, you would ideally sandbox this (e.g., iframe with strict policies, web worker, or server-side rendering).

      // Create a function that takes React and exports PreviewComponent
      const codeFunction = new Function('React', 'ReactDOM', 'exports', generatedCode + '; return exports.PreviewComponent;');
      const exports: { PreviewComponent?: React.FC } = {};

      // Execute the function in a controlled environment
      const component = codeFunction(React, undefined, exports); // Pass React
      if (typeof component === 'function') {
        setComponentToRender(() => component); // Use functional update for useState
      } else {
        throw new Error('Generated code did not export a valid React component named PreviewComponent.');
      }
    } catch (e: any) {
      const errorMsg = e instanceof Error ? e.message : String(e);
      setCompileError(`Compilation Error: ${errorMsg}`);
      onCompileError(errorMsg);
      setComponentToRender(null);
    }
  }, [generatedCode, onCompileError]);

  const handleRuntimeError = useMemo(() => (error: Error, errorInfo: React.ErrorInfo) => {
    console.error("Runtime Error in Preview Component:", error, errorInfo);
    onRuntimeError(`Runtime Error: ${error.message}`);
  }, [onRuntimeError]);

  if (compileError) {
    return (
      <div className="flex items-center justify-center h-full bg-red-900 text-red-100 p-4 rounded-lg overflow-auto">
        <pre className="text-sm" style={errorBoundaryStyle}>{compileError}</pre>
      </div>
    );
  }

  if (!ComponentToRender) {
    return (
      <div className="flex items-center justify-center h-full bg-gray-800 text-gray-400 p-4 rounded-lg">
        <p className="text-xl">Preview will appear here after code generation...</p>
      </div>
    );
  }

  return (
    <div className="relative h-full w-full bg-gray-800 rounded-lg overflow-auto">
      <ErrorBoundary onError={handleRuntimeError} fallback={
        <pre className="text-sm" style={errorBoundaryStyle}>
          A runtime error occurred in the preview. Please check the console for details.
        </pre>
      }>
        <ComponentToRender />
      </ErrorBoundary>
    </div>
  );
};

export default PreviewPane;
