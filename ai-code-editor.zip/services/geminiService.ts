import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GEMINI_MODEL_CODE_GENERATION, GEMINI_MODEL_ERROR_ANALYSIS } from '../constants';

// CRITICAL: New GoogleGenAI instance must be created right before an API call
// to ensure it uses the most up-to-date API key from the dialog if opened.
// The API key is assumed to be available via process.env.API_KEY.

/**
 * Calls the Gemini API to generate or update code based on a prompt.
 * @param prompt The user's prompt for code generation.
 * @param currentCode Optional: The existing code to be updated.
 * @returns A promise that resolves to the generated code string.
 */
export async function generateCodeWithGemini(
  prompt: string,
  currentCode: string = ''
): Promise<string> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const messages = [
    {
      role: 'user',
      parts: [{
        text: `You are an expert React TypeScript developer. Your task is to generate or update a React functional component named 'PreviewComponent'.
          The component should be exported as 'export const PreviewComponent: React.FC = () => { /* ... */ };'
          It should use Tailwind CSS for styling. Do not include any external imports beyond 'react'.
          If a current code is provided, update it according to the prompt.
          Your response should ONLY contain the full, updated or new TypeScript React component code, nothing else.

          Prompt: "${prompt}"
          ${currentCode ? `Current code to update:\n\`\`\`tsx\n${currentCode}\n\`\`\`` : ''}
          `,
      }],
    },
  ];

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_CODE_GENERATION,
      contents: messages,
      config: {
        maxOutputTokens: 2048, // Generous token limit for code
        temperature: 0.7,
        topP: 0.95,
      },
    });
    return response.text?.trim() || '';
  } catch (error) {
    console.error("Error generating code with Gemini:", error);
    throw new Error(`Failed to generate code: ${error instanceof Error ? error.message : String(error)}`);
  }
}

/**
 * Calls the Gemini API to analyze an error and suggest fixes for the code.
 * @param code The code that caused the error.
 * @param errorMessage The error message received.
 * @returns A promise that resolves to the AI's analysis and suggested fixes.
 */
export async function analyzeCodeErrorWithGemini(
  code: string,
  errorMessage: string
): Promise<string> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const messages = [
    {
      role: 'user',
      parts: [{
        text: `I encountered an error with the following React TypeScript component.
          Please analyze the error and suggest specific fixes. Explain your reasoning clearly.
          Your response should be in markdown format.

          Error message:
          \`\`\`
          ${errorMessage}
          \`\`\`

          Code:
          \`\`\`tsx
          ${code}
          \`\`\`
          `,
      }],
    },
  ];

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_ERROR_ANALYSIS,
      contents: messages,
      config: {
        maxOutputTokens: 1024,
        temperature: 0.5,
      },
    });
    return response.text?.trim() || 'No analysis available.';
  } catch (error) {
    console.error("Error analyzing code with Gemini:", error);
    throw new Error(`Failed to analyze error: ${error instanceof Error ? error.message : String(error)}`);
  }
}

/**
 * Calls the Gemini API to analyze code for general improvements and best practices.
 * @param code The code to be analyzed for improvements.
 * @returns A promise that resolves to the AI's suggestions for improvement.
 */
export async function analyzeCodeForImprovements(code: string): Promise<string> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const messages = [
    {
      role: 'user',
      parts: [{
        text: `You are an expert React TypeScript developer. Analyze the following React functional component for best practices, readability, performance, and overall code quality. Suggest specific improvements and explain your reasoning clearly.
          Your response should be in markdown format. Do not rewrite the entire component unless necessary; focus on actionable suggestions.

          Code to analyze:
          \`\`\`tsx
          ${code}
          \`\`\`
          `,
      }],
    },
  ];

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_ERROR_ANALYSIS, // Using flash model for quick analysis
      contents: messages,
      config: {
        maxOutputTokens: 1024,
        temperature: 0.5,
      },
    });
    return response.text?.trim() || 'No improvement suggestions available.';
  } catch (error) {
    console.error("Error analyzing code for improvements with Gemini:", error);
    throw new Error(`Failed to get improvement suggestions: ${error instanceof Error ? error.message : String(error)}`);
  }
}