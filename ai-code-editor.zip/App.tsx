import React, { useState, useEffect, useRef, useCallback } from 'react';
import CodeEditor from './components/CodeEditor';
import PreviewPane from './components/PreviewPane';
import ChatInput from './components/ChatInput';
import ChatMessageComponent from './components/ChatMessage';
import ErrorDisplay from './components/ErrorDisplay';
import { generateCodeWithGemini, analyzeCodeErrorWithGemini, analyzeCodeForImprovements } from './services/geminiService';
import { LOCAL_STORAGE_CODE_KEY, LOCAL_STORAGE_CHAT_HISTORY_KEY, INITIAL_CODE_SNIPPET } from './constants';
import { ChatMessage, StoredData } from './types';
import { v4 as uuidv4 } from 'uuid'; // For unique message IDs


// Check for API key presence
const hasApiKey = !!process.env.API_KEY;

const App: React.FC = () => {
  const [code, setCode] = useState<string>(
    localStorage.getItem(LOCAL_STORAGE_CODE_KEY) || INITIAL_CODE_SNIPPET
  );
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>(() => {
    const storedHistory = localStorage.getItem(LOCAL_STORAGE_CHAT_HISTORY_KEY);
    return storedHistory ? JSON.parse(storedHistory) : [];
  });
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [compileError, setCompileError] = useState<string | null>(null);
  const [runtimeError, setRuntimeError] = useState<string | null>(null);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<'code' | 'preview'>('code'); // New state for view toggle

  const chatMessagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom of chat history on new messages
  useEffect(() => {
    if (chatMessagesEndRef.current) {
      chatMessagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatHistory]);

  // Persist code and chat history to local storage
  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_CODE_KEY, code);
  }, [code]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_CHAT_HISTORY_KEY, JSON.stringify(chatHistory));
  }, [chatHistory]);

  // Function to handle AI key selection if needed (e.g., for Veo/Imagen models)
  const handleSelectApiKey = useCallback(async () => {
    if (window.aistudio && window.aistudio.openSelectKey) {
      try {
        await window.aistudio.openSelectKey();
        // Assuming key selection was successful, proceed.
        // The API_KEY env var should now be updated implicitly.
        alert('API key selected successfully! You can now use AI features.');
        window.location.reload(); // Reload to ensure new key is picked up by GoogleGenAI instance
      } catch (error) {
        console.error("Failed to select API key:", error);
        alert('Failed to select API key. Please ensure you select a key from a paid GCP project.');
      }
    } else {
      alert('`window.aistudio` not available. Ensure you are running in the correct environment.');
    }
  }, []);

  const handleSendMessage = useCallback(async (message: string) => {
    if (!hasApiKey) {
      alert('API Key is missing! Please configure process.env.API_KEY or select one using the "Select API Key" button.');
      return;
    }

    const newUserMessage: ChatMessage = { id: uuidv4(), role: 'user', content: message };
    setChatHistory((prev) => [...prev, newUserMessage]);
    setIsLoading(true);
    setCompileError(null);
    setRuntimeError(null);
    setAiAnalysis(null);

    try {
      const aiResponse = await generateCodeWithGemini(message, code);
      setCode(aiResponse);
      const newAiMessage: ChatMessage = { id: uuidv4(), role: 'model', content: "Code updated successfully!" };
      setChatHistory((prev) => [...prev, newAiMessage]);
    } catch (error) {
      console.error("Error in AI code generation:", error);
      const errorMessage = `Failed to generate code: ${error instanceof Error ? error.message : String(error)}`;
      const errorChat: ChatMessage = { id: uuidv4(), role: 'error', content: errorMessage };
      setChatHistory((prev) => [...prev, errorChat]);
    } finally {
      setIsLoading(false);
    }
  }, [code, chatHistory, hasApiKey]);

  const handleCompileError = useCallback(async (errorMsg: string) => {
    setCompileError(errorMsg);
    setRuntimeError(null); // Clear runtime error if new compile error
    setAiAnalysis(null); // Clear previous analysis

    if (!hasApiKey) {
      // Don't attempt AI analysis if no API key
      return;
    }

    setIsLoading(true);
    try {
      const analysis = await analyzeCodeErrorWithGemini(code, errorMsg);
      setAiAnalysis(analysis);
      const analysisChat: ChatMessage = { id: uuidv4(), role: 'model', content: `**AI Code Analysis (Compile Error):**\n\n${analysis}` };
      setChatHistory((prev) => [...prev, analysisChat]);
    } catch (error) {
      console.error("Error in AI error analysis:", error);
      const analysisChat: ChatMessage = { id: uuidv4(), role: 'error', content: `Failed to get AI analysis: ${error instanceof Error ? error.message : String(error)}` };
      setChatHistory((prev) => [...prev, analysisChat]);
    } finally {
      setIsLoading(false);
    }
  }, [code, chatHistory, hasApiKey]);

  const handleRuntimeError = useCallback(async (errorMsg: string) => {
    setRuntimeError(errorMsg);
    setCompileError(null); // Clear compile error if new runtime error
    setAiAnalysis(null); // Clear previous analysis

    if (!hasApiKey) {
      // Don't attempt AI analysis if no API key
      return;
    }

    setIsLoading(true);
    try {
      const analysis = await analyzeCodeErrorWithGemini(code, errorMsg);
      setAiAnalysis(analysis);
      const analysisChat: ChatMessage = { id: uuidv4(), role: 'model', content: `**AI Code Analysis (Runtime Error):**\n\n${analysis}` };
      setChatHistory((prev) => [...prev, analysisChat]);
    } catch (error) {
      console.error("Error in AI error analysis:", error);
      const analysisChat: ChatMessage = { id: uuidv4(), role: 'error', content: `Failed to get AI analysis: ${error instanceof Error ? error.message : String(error)}` };
      setChatHistory((prev) => [...prev, analysisChat]);
    } finally {
      setIsLoading(false);
    }
  }, [code, chatHistory, hasApiKey]);

  const handleSuggestImprovements = useCallback(async () => {
    if (!hasApiKey) {
      alert('API Key is missing! Please configure process.env.API_KEY or select one using the "Select API Key" button.');
      return;
    }

    const newUserMessage: ChatMessage = { id: uuidv4(), role: 'user', content: 'Please suggest improvements for the current code.' };
    setChatHistory((prev) => [...prev, newUserMessage]);
    setIsLoading(true);
    setCompileError(null);
    setRuntimeError(null);
    setAiAnalysis(null); // Clear previous error analysis

    try {
      const analysis = await analyzeCodeForImprovements(code);
      const analysisChat: ChatMessage = { id: uuidv4(), role: 'model', content: `**AI Code Improvement Suggestions:**\n\n${analysis}` };
      setChatHistory((prev) => [...prev, analysisChat]);
    } catch (error) {
      console.error("Error in AI improvement analysis:", error);
      const analysisChat: ChatMessage = { id: uuidv4(), role: 'error', content: `Failed to get AI improvement suggestions: ${error instanceof Error ? error.message : String(error)}` };
      setChatHistory((prev) => [...prev, analysisChat]);
    } finally {
      setIsLoading(false);
    }
  }, [code, chatHistory, hasApiKey]);

  const clearError = useCallback(() => {
    setCompileError(null);
    setRuntimeError(null);
    setAiAnalysis(null);
  }, []);

  return (
    <div className="flex h-screen bg-gray-900 text-gray-100 antialiased">
      {/* Left Sidebar - Chat History */}
      <div className="w-1/4 bg-gray-800 border-r border-gray-700 flex flex-col p-4">
        <h2 className="text-xl font-bold mb-4 text-blue-400">AI Code Studio Chat</h2>
        <div className="flex-grow overflow-y-auto pr-2 custom-scrollbar">
          {chatHistory.length === 0 && (
            <p className="text-gray-400 text-center mt-8">Start a conversation with AI!</p>
          )}
          {chatHistory.map((msg) => (
            <ChatMessageComponent key={msg.id} message={msg} />
          ))}
          <div ref={chatMessagesEndRef} />
        </div>
        <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
      </div>

      {/* Main Content Area */}
      <div className="flex-grow flex flex-col">
        {/* Top Bar for API Key Selection, Title, and View Toggles */}
        <div className="flex flex-col sm:flex-row items-center justify-between p-4 bg-gray-800 border-b border-gray-700">
          <h1 className="text-xl font-bold text-blue-400 mb-2 sm:mb-0">AI Code Editor & Preview</h1>
          
          {/* View Toggle Buttons */}
          <div className="flex space-x-2 my-2 sm:my-0">
            <button
              onClick={() => setCurrentView('code')}
              className={`px-4 py-2 rounded-lg font-semibold transition-colors duration-200 ${
                currentView === 'code' ? 'bg-blue-600 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
              }`}
            >
              Code
            </button>
            <button
              onClick={() => setCurrentView('preview')}
              className={`px-4 py-2 rounded-lg font-semibold transition-colors duration-200 ${
                currentView === 'preview' ? 'bg-blue-600 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
              }`}
            >
              Preview
            </button>
          </div>

          <div className="flex items-center space-x-4">
            {!hasApiKey && (
              <div className="flex items-center space-x-2">
                <span className="text-red-400 text-sm">API Key Missing!</span>
                <button
                  onClick={handleSelectApiKey}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-lg text-white font-semibold transition-colors duration-200"
                >
                  Select API Key
                </button>
                <a
                  href="https://ai.google.dev/gemini-api/docs/billing"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-400 hover:underline text-sm"
                >
                  Billing Info
                </a>
              </div>
            )}
            <button
              onClick={handleSuggestImprovements}
              className={`px-4 py-2 rounded-lg font-semibold transition-colors duration-200 ${
                isLoading || !hasApiKey
                  ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
                  : 'bg-green-600 hover:bg-green-700 text-white'
              }`}
              disabled={isLoading || !hasApiKey}
              title={!hasApiKey ? "Please select an API key to enable AI features" : "Get AI suggestions for improving your code"}
            >
              Suggest Improvements
            </button>
          </div>
        </div>

        {/* Code Editor or Preview (Conditionally Rendered) */}
        <div className="flex-grow p-4 relative">
          {currentView === 'code' && (
            <div className="flex flex-col h-full">
              <h3 className="text-lg font-semibold mb-2 text-gray-300">Code Editor</h3>
              <CodeEditor code={code} onCodeChange={setCode} />
            </div>
          )}
          {currentView === 'preview' && (
            <div className="flex flex-col h-full">
              <h3 className="text-lg font-semibold mb-2 text-gray-300">Live Preview</h3>
              <PreviewPane
                generatedCode={code}
                onCompileError={handleCompileError}
                onRuntimeError={handleRuntimeError}
              />
            </div>
          )}

          {(compileError || runtimeError) && (
            <ErrorDisplay
              errorMessage={compileError || runtimeError}
              aiAnalysis={aiAnalysis}
              onClearError={clearError}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default App;